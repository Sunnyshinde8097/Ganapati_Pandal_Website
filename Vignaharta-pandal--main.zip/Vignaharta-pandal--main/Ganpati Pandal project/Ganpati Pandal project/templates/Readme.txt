The folder has all the HTML files.

Thank You!!