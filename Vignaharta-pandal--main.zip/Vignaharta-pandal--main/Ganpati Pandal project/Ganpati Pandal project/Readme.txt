The project has been divided into two verticals.
	i) The frontend
	ii) The backend
The frontend is designed in HTML, Javascript, and CSS.
For the backend, we have used Python with the Flask framework.
For data preparation, we used MS Excel, and to load the data into the database, we used MySQL Workbench.

app.py file is the main python file for frontend and dbm.py is the file for database connectivity.
 
The folder Data for Ganpati Pandal has the data of pandals and the tableau file.

The static folder has the images and the CSS file & javascript files.

The templates folder has all the HTML files.

Thank You!!