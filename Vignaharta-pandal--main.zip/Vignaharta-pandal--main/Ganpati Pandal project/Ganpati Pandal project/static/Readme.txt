The folder has the images and the CSS file & javascript files.


Thank You!!