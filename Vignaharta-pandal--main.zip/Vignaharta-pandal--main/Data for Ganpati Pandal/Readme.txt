The folder contains the famous_ganpati_to_visit.csv file which is loaded in the database.

and tableau twbx file for visualization of the city and count of pandals on the map.


Thank You!!